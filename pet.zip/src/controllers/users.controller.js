import { usersService } from "../services/index.js"


export class UserControllers {
    constructor(usersService) {
        //Al instanciar una clase se ejecuta el constructor
        //Variables que pertenecen a la clase
        this.usersService = usersService
    }
        showUser() {
            console.log('Joel')
        }
    //Instanciar la clase y pasar el parametro name
    //userControllers = new UserControllers(usersService)    
    getAllUsers = async (req, res) => {
        users = await this.usersService.getAll();
        res.send({ status: "success", payload: users })
    }

    getUser = async (req, res) => {
        userId = req.params.uid;
        user = await this.usersService.getUserById(userId);
        if (!user) return res.status(404).send({ status: "error", error: "User not found" })
        res.send({ status: "success", payload: user })
    }

    updateUser = async (req, res) => {
        updateBody = req.body;
        userId = req.params.uid;
        user = await this.usersService.getUserById(userId);
        if (!user) return res.status(404).send({ status: "error", error: "User not found" })
        result = await usersService.update(userId, updateBody);
        res.send({ status: "success", message: "User updated" })
    }

    deleteUser = async (req, res) => {
        userId = req.params.uid;
        result = await this.usersService.getUserById(userId);
        res.send({ status: "success", message: "User deleted" })
    }

}